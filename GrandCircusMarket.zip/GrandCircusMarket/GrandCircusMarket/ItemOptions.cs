﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GrandCircusMarket
{
    public enum ItemOptions
    {
        Chicken = 1,
        Beef,
        Fish,
        Pork,
        Apple,
        Orange,
        Kale,
        Spinach,
        Water,
        Juice,
        Coffee,
        Beer
    }
}
